from scudo_regression.cli import main

main()
